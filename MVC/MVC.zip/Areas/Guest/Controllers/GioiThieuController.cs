﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVC.Areas.Guest.Controllers
{
    public class GioiThieuController : Controller
    {
        //
        // GET: /Guest/GioiThieu/

        public ActionResult Index()
        {

            return View();
        }

    }
}
