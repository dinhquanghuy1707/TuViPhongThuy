using System;
using System.Collections.Generic;

namespace MVC.Models
{
    public partial class BatQuai_TuTrach
    {
        public int MaBatQuai { get; set; }
        public string TuTrach { get; set; }
        public string Cung { get; set; }
    }
}
