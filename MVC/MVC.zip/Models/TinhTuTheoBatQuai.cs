using System;
using System.Collections.Generic;

namespace MVC.Models
{
    public partial class TinhTuTheoBatQuai
    {
        public int MaBatQuai { get; set; }
        public string Huong { get; set; }
        public Nullable<int> MaTinhTu { get; set; }
    }
}
