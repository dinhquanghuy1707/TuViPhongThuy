using System;
using System.Collections.Generic;

namespace MVC.Models
{
    public partial class NguHanh
    {
        public int namDL { get; set; }
        public string namAL { get; set; }
        public string GiaiNghia { get; set; }
        public string CungNam { get; set; }
        public string NienMenhNam { get; set; }
        public string CungNu { get; set; }
        public string NienMenhNu { get; set; }
        public string NguHanhNamSinh { get; set; }
        public string TenNguHanh { get; set; }
    }
}
