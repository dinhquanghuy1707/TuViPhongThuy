using System;
using System.Collections.Generic;

namespace MVC.Models
{
    public partial class TinhTu
    {
        public int MaTinhTu { get; set; }
        public string TenTinhTu { get; set; }
        public string LoaiTinhTu { get; set; }
        public string GiaiThich { get; set; }
    }
}
