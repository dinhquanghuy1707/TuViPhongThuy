using System;
using System.Collections.Generic;

namespace MVC.Models
{
    public partial class BoiTinhDuyenPost
    {
        public string IdPost { get; set; }
        public string Gender1 { get; set; }
        public string Gender2 { get; set; }
        public string Dob1 { get; set; }
        public string Dob2 { get; set; }
        public string Image { get; set; }
    }
}
